import dena0034Library

circleRadius = float(input("What is the radius?: "))
a = dena0034Library.areaCircle(circleRadius)
print("The area of a circle of radius r= {1} is {0}".format(a, circleRadius))
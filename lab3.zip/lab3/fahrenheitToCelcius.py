#this program convert fahrenheit to celcius

degreeFah = float(input("What is the tempeture in Fahrenheit?: "))

degreeCelcius = ( (degreeFah - 32) * 5/9)

print("The degree in Celcius is: ", degreeCelcius)